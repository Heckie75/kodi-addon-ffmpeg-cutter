import sys
import cutter

if __name__ == '__main__':
    cutter = Cutter()
    cutter.cut(sys.listitem)