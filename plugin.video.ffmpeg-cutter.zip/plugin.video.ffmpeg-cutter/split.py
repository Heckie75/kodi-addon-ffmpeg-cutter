import sys
import cutter

if __name__ == '__main__':
    cutter.split(sys.listitem)